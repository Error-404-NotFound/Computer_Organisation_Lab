#include<stdio.h>

int main()
{
    int a=3;
    int b=4;
    printf("The sum of a and b is %d\n",a+b);
    return 0;
}